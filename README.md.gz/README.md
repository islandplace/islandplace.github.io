# 聯絡及相關資料 | Contacts and Related Informations

- [網頁 | Website](https://islandplace.github.io)

- [Facebook專頁 | Facebook Page](https://www.facebook.com/islandplace19)

- [WhatsApp](//wa.me/85297099153?text=你好，我喺github見到你地個樓盤，想請問咩時候方便約睇？)

- [電話 | Phone](https://islandplace.github.io/phone.html)

# 樓盤簡介 | Real Estate Descriptions

## ⚡️終極劈售⚡️ 北角港運城低層 罕有荀盤 業主免佣急走🔥 一減再減超200萬❗️全港至抵❗️ 🔻大減近一成三🔻

北角 港運城 業主盤🏠

罕有荀盤 低層 減價出售🤑

實用777呎 建974呎🔥

三房兩廁 超值抵住😘

單位望花園景🏡

客飯廳有南北對流窗 冬暖夏涼🛁

屋苑特設平台花園及游池🏖

交通方便 3分鐘到港鐵⏱

樓下商場設超市 2分鐘到食肆 5分鐘到街市⌛️

3-5分鐘到健身中心 $498-788/月🏋️‍♂️

5分鐘到北角海濱花園 🏝

有匙 歡迎PM預約睇樓 直接查詢🙏🏻📱

另有更多圖片 歡迎DM查看🖼🛋

售價：1398萬 👍🏻👍🏻👍🏻💰

由千六萬 一減再減 價啱即走🎰

## ⚡️FINAL SALE⚡️ North Point low floor Commission free❗️ Massive dropped $2000k❗️ 🔻dropped ~13%🔻

North Point Island Place owner release🏠

Rarely releases, lower floor for sale🤑

Usable area: 777ft

Construction area: 974ft🔥

Three bedrooms, two toilets. Extremely cheap to move in. 😘

Garden view outside. 🏡

Dining room has convection windows face south. Warm in winter and cool in summer. 🛁

Estate has public garden and swimming pool. 🏖

Convenient transportation 3 minutes to the MTR. ⏱

Downstairs shopping mall with supermarket, 2 minutes to restaurant and 5 minutes to market. ⌛️

3-5 min to gym centre $498-788/month🏋️‍♂️ 

5 min to North Point Promenade🏝

Feel free to leave a message to make an appointment to visit us. 🙏🏻📱

There is more photo to view, it is welcome to send a DM to see more. 🖼🛋

Price：🔻$13.98m🔻 👍🏻👍🏻👍🏻💰

Price dropped from $1600k again and again. Just would like to make deal in market price. 🎰
